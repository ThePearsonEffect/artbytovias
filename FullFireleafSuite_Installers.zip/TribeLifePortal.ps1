Write-Host "🌱 Welcome to the TribeLife Coaching Portal..."
Start-Process "https://example.com/tribelife"  # Replace with real link