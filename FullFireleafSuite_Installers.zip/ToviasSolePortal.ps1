Write-Host "🛍️ Welcome to the Tovias Solé Bookstore Portal..."
Start-Process "https://example.com/toviassole"  # Replace with real link