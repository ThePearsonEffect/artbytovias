Write-Host "🚀 Launching Full Fireleaf Suite Installation..."

Start-Process -FilePath "$PSScriptRoot\LankyBoisPortal.ps1"
Start-Process -FilePath "$PSScriptRoot\TribeLifePortal.ps1"
Start-Process -FilePath "$PSScriptRoot\ToviasSolePortal.ps1"