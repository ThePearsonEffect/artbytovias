Write-Host "👕 Welcome to the Lanky Bois Clothing Portal..."
Start-Process "https://example.com/lankybois"  # Replace with real link